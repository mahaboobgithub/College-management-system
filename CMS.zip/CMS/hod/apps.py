from django.apps import AppConfig


class HodConfig(AppConfig):
    name = 'hod'
